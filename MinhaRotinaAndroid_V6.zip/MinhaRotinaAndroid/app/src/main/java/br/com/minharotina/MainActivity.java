package br.com.minharotina;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    public static final String PREFS = "MinhaRotinaPrefs";
    WebView web;
    static final int REQ_NOTIF=700, REQ_CAL=701;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(android.graphics.Color.rgb(11,11,13)); getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,11,13));
        web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setBuiltInZoomControls(false); web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new Bridge(this),"Android"); web.loadUrl("file:///android_asset/minha_rotina.html"); }
    void askNotifications(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF); if(Build.VERSION.SDK_INT>=31){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); if(!am.canScheduleExactAlarms()) try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception ignored){} } }
    void askCalendar(){ if(Build.VERSION.SDK_INT>=23 && (checkSelfPermission(Manifest.permission.WRITE_CALENDAR)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.READ_CALENDAR)!=PackageManager.PERMISSION_GRANTED)) requestPermissions(new String[]{Manifest.permission.READ_CALENDAR,Manifest.permission.WRITE_CALENDAR},REQ_CAL); else Toast.makeText(this,"Calendário já autorizado.",Toast.LENGTH_SHORT).show(); }
    public class Bridge{
        MainActivity a; Bridge(MainActivity x){a=x;}
        @JavascriptInterface public void requestNotifications(){a.runOnUiThread(a::askNotifications);}
        @JavascriptInterface public void syncAlarms(String tasksJson,int lead,boolean enabled,boolean sound){a.runOnUiThread(()->{ if(!enabled){AlarmScheduler.cancelAll(a);return;} a.askNotifications(); AlarmScheduler.scheduleAll(a,tasksJson,lead,sound); });}
        @JavascriptInterface public void syncCalendar(String tasksJson){a.runOnUiThread(()->{ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.WRITE_CALENDAR)!=PackageManager.PERMISSION_GRANTED){askCalendar(); Toast.makeText(a,"Autorize o calendário e toque em sincronizar novamente.",Toast.LENGTH_LONG).show();} else CalendarSync.sync(a,tasksJson); });}
        @JavascriptInterface public void requestCalendar(){a.runOnUiThread(a::askCalendar);}
    }
}
