# Minha Rotina 6.0

Versão inicial da nova experiência do Minha Rotina, preparada para compilação em nuvem pelo GitHub Actions.

## O que já está nesta versão
- Tela Hoje com próxima tarefa, progresso e conclusão.
- Animação de conclusão e tela final “Tudo certo por hoje”.
- Tarefas atrasadas com Fazer agora / Reprogramar / Pular hoje.
- Reprogramação procurando espaços livres do horário atual até 00:30.
- Agenda mensal e semanal.
- Progresso semanal e mensal.
- Configurações e gerenciamento de tarefas recorrentes.
- Dias da semana podem ser marcados/desmarcados sem duplicar a tarefa.
- Exclusão da rotina inteira de uma tarefa.
- Notificações nativas e alarmes.
- Sincronização com calendário Android.
- Ícone próprio do Minha Rotina em carvão/cinza, sem neon.
- Paleta escura, minimalista e discreta.

## Compilação pelo telefone
1. Crie/substitua o repositório pelo conteúdo desta pasta.
2. Faça push para `main` ou abra Actions e execute `Build Minha Rotina APK` manualmente.
3. Baixe o artefato `MinhaRotina-v3-debug-apk`.
4. Instale `app-debug.apk` no Android.

A versão usa Gradle 8.9 e Java 17 no GitHub Actions.

## Novidades da 4.0
- Estados automáticos: **Tudo concluído** (tela cheia), **Sono** (do horário de dormir até o de acordar) e **Novo dia** ("Bom dia, Math.").
- Horários de dormir e acordar configuráveis em Configurações > Sono.
- Lembretes de sono (1h e 30 min antes de dormir) e opção "Nunca" nas notificações.
- Visual cinza/branco/preto inspirado em iOS.
- Correções: tarefas após a meia-noite (ex.: Dormir 00:30) deixam de aparecer como atrasadas o dia todo; datas usam o horário local, não UTC.

## Novidades da 5.0
- Relógio do dia na tela Hoje, com arcos coloridos por categoria e ponteiro na hora atual.
- Cores neutras por categoria, sequência de dias e visual translúcido (sem blur, para ficar leve).
- Botão ✓: toque conclui (toque de novo desfaz); segure para Adiar, Cancelar hoje ou Fazer agora.
- Tarefas atrasadas agrupadas ("Atrasadas · N") com Concluir todas / Pular todas.
- Animações: entrada em cascata, pop ao concluir, cartão que troca, navegação deslizando.
- Agenda: tocar num dia mostra as tarefas daquele dia; troca de mês corrigida.
- Perfil: nome editável (pergunta na primeira abertura e em Configurações).
- Backup: exportar e restaurar os dados em Configurações > Dados.
- Menos redesenhos: a tela só atualiza quando algo muda.

## Novidades da 6.0
- Temas: Dourado (atual), Névoa (pastel claro), Rosé (claro feminino) e Rosé noturno, com modo Automático (claro de dia, escuro à noite).
- Cores das categorias editáveis em Configurações > Aparência; cada tarefa pode ter categoria própria ou automática.
- Configurações redesenhada: grupos alinhados, switches, antecedência em botões, subtelas de Tema, Cores, Backup e Diagnóstico.
- Editor de tarefa novo: categoria e cor, tipo Fixa/Flexível, descrição e local.
- Correção interna: o CSS das versões 4 e 5 tinha tags quebradas, e algumas regras (como a remoção do blur) não eram aplicadas. Agora aplicam.
