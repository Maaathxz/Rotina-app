package br.com.minharotina;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if(c.getSharedPreferences(MainActivity.PREFS,0).getBoolean("enabled",false)) {
            AlarmScheduler.scheduleAll(c,c.getSharedPreferences(MainActivity.PREFS,0).getInt("lead",15),c.getSharedPreferences(MainActivity.PREFS,0).getBoolean("sound",true));
        }
    }
}
