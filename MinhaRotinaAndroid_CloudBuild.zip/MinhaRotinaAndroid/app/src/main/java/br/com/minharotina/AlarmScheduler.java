package br.com.minharotina;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class AlarmScheduler {
    private AlarmScheduler() {}
    private static final String[] DAYS = {"Domingo","Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado"};
    // day: Calendar.SUNDAY=1 ... SATURDAY=7; time HH:mm; title
    static final String[][][] ITEMS = new String[][][] {
        {{"2","08:30","Acordar"},{"2","09:00","Café da manhã"},{"2","09:30","Estudo — matéria mais difícil"},{"2","11:00","Pausa"},{"2","11:20","Programação"},{"2","12:20","Almoço + descanso"},{"2","13:30","Revisão da faculdade"},{"2","14:30","Lazer"},{"2","15:30","Treino"},{"2","17:00","Banho + lanche"},{"2","18:20","Jantar / deslocamento"},{"2","19:00","Faculdade"},{"2","22:00","Volta + jantar"},{"2","23:00","Descompressão"},{"2","00:30","Dormir"}},
        {{"3","08:30","Acordar"},{"3","09:00","Café da manhã"},{"3","09:30","Programação — prática"},{"3","11:00","Pausa"},{"3","11:20","Estudo — faculdade"},{"3","12:20","Almoço + descanso"},{"3","13:30","Trabalhos da faculdade"},{"3","14:30","Lazer"},{"3","15:30","Treino"},{"3","17:00","Banho + descanso"},{"3","18:20","Jantar / deslocamento"},{"3","19:00","Faculdade"},{"3","22:00","Jantar + descanso"},{"3","23:00","Tempo livre"},{"3","00:30","Dormir"}},
        {{"4","08:30","Acordar"},{"4","09:00","Café da manhã"},{"4","09:30","Estudo / revisão"},{"4","11:00","Pausa"},{"4","11:20","Programação"},{"4","12:20","Almoço + descanso"},{"4","13:30","Trabalhos da faculdade"},{"4","14:30","Lazer"},{"4","16:00","Caminhada / cardio leve"},{"4","17:00","Banho + jantar"},{"4","19:00","Faculdade"},{"4","22:00","Volta + jantar"},{"4","23:00","Tempo livre"},{"4","00:30","Dormir"}},
        {{"5","08:30","Acordar"},{"5","09:00","Café da manhã"},{"5","09:30","Estudo — faculdade"},{"5","11:00","Pausa"},{"5","11:20","Programação"},{"5","12:20","Almoço + descanso"},{"5","13:30","Trabalhos / revisão"},{"5","14:30","Lazer"},{"5","15:30","Treino"},{"5","17:00","Banho + lanche"},{"5","18:20","Jantar / deslocamento"},{"5","19:00","Faculdade"},{"5","22:00","Jantar + descanso"},{"5","23:00","Tempo livre"},{"5","00:30","Dormir"}},
        {{"6","08:30","Acordar"},{"6","09:00","Café da manhã"},{"6","09:30","Revisão da semana"},{"6","11:00","Pausa"},{"6","11:20","Programação / projeto pessoal"},{"6","12:20","Almoço + descanso"},{"6","14:00","Organizar trabalhos pendentes"},{"6","15:00","Lazer"},{"6","16:00","Treino"},{"6","17:30","Banho + jantar"},{"6","19:00","Faculdade"},{"6","22:00","Noite livre"},{"6","00:30","Dormir"}},
        {{"7","09:00","Acordar"},{"7","09:30","Café da manhã"},{"7","10:00","Estudo"},{"7","11:30","Pausa"},{"7","12:00","Programação"},{"7","13:00","Almoço"},{"7","14:30","Treino"},{"7","16:00","Banho + descanso"},{"7","17:00","Lazer"},{"7","19:00","Noite livre"},{"7","00:30","Dormir"}},
        {{"1","09:00","Acordar"},{"1","09:30","Café da manhã"},{"1","10:00","Organizar quarto / coisas pessoais"},{"1","11:00","Revisão leve"},{"1","12:00","Almoço + família"},{"1","14:00","Lazer"},{"1","17:00","Planejar a próxima semana"},{"1","17:30","Tempo livre"},{"1","20:00","Jantar"},{"1","21:00","Preparar segunda-feira"},{"1","22:00","Relaxar"},{"1","00:00","Preparar para dormir"},{"1","00:30","Dormir"}}
    };

    static void scheduleAll(Context c, int lead, boolean sound) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        int id=1000;
        for (String[][] day: ITEMS) for (String[] item: day) {
            long when=nextMillis(Integer.parseInt(item[0]), item[1])-lead*60_000L;
            if (when <= System.currentTimeMillis()+1000) continue;
            Intent i=new Intent(c, AlarmReceiver.class).putExtra("title", item[2]).putExtra("sound", sound).putExtra("day", Integer.parseInt(item[0])).putExtra("time", item[1]).putExtra("id", id);
            PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else if (Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
            else am.set(AlarmManager.RTC_WAKEUP,when,pi);
            id++;
        }
        c.getSharedPreferences(MainActivity.PREFS,0).edit().putBoolean("enabled",true).putInt("lead",lead).putBoolean("sound",sound).apply();
    }
    static void scheduleNext(Context c,int day,String time,String title,boolean sound,int id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        long when=nextMillis(day,time);
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("title",title).putExtra("sound",sound).putExtra("day",day).putExtra("time",time).putExtra("id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
    }
    static long nextMillis(int day,String hm){
        Calendar n=Calendar.getInstance(), d=Calendar.getInstance(); d.set(Calendar.SECOND,0); d.set(Calendar.MILLISECOND,0);
        String[] p=hm.split(":"); d.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0])); d.set(Calendar.MINUTE,Integer.parseInt(p[1]));
        int delta=(day-d.get(Calendar.DAY_OF_WEEK)+7)%7; if(delta==0 && d.getTimeInMillis()<=n.getTimeInMillis()) delta=7; d.add(Calendar.DAY_OF_MONTH,delta); return d.getTimeInMillis();
    }
    static void cancelAll(Context c){ AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); int id=1000; for(String[][] day:ITEMS) for(String[] x:day){ PendingIntent p=PendingIntent.getBroadcast(c,id++,new Intent(c,AlarmReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); am.cancel(p); p.cancel(); } c.getSharedPreferences(MainActivity.PREFS,0).edit().putBoolean("enabled",false).apply(); }
}
