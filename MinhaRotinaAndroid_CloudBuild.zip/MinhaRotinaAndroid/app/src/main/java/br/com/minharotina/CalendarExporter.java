package br.com.minharotina;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public final class CalendarExporter {
    private CalendarExporter(){}

    public static void exportAndShare(Context c){
        try {
            StringBuilder out=new StringBuilder();
            out.append("BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Minha Rotina//PT-BR//EN\r\nCALSCALE:GREGORIAN\r\n");
            int uid=0;
            for(String[][] day: AlarmScheduler.ITEMS){
                for(String[] item: day){
                    int dow=Integer.parseInt(item[0]);
                    String hm=item[1];
                    Calendar start=nextDate(dow,hm);
                    Calendar end=(Calendar)start.clone(); end.add(Calendar.MINUTE,30);
                    out.append("BEGIN:VEVENT\r\n");
                    out.append("UID:minha-rotina-").append(System.currentTimeMillis()).append("-").append(uid++).append("@minharotina\r\n");
                    out.append("DTSTAMP:").append(fmt(Calendar.getInstance())).append("\r\n");
                    out.append("DTSTART:").append(fmt(start)).append("\r\n");
                    out.append("DTEND:").append(fmt(end)).append("\r\n");
                    out.append("RRULE:FREQ=WEEKLY\r\n");
                    out.append("SUMMARY:").append(escape(item[2])).append("\r\n");
                    out.append("DESCRIPTION:Minha Rotina\r\n");
                    out.append("END:VEVENT\r\n");
                }
            }
            out.append("END:VCALENDAR\r\n");

            File f=new File(c.getCacheDir(),"minha-rotina.ics");
            try(FileOutputStream fos=new FileOutputStream(f)){fos.write(out.toString().getBytes("UTF-8"));}
            Uri uri=Uri.parse("content://br.com.minharotina.fileprovider/minha-rotina.ics");
            Intent send=new Intent(Intent.ACTION_SEND);
            send.setType("text/calendar");
            send.putExtra(Intent.EXTRA_STREAM,uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(Intent.createChooser(send,"Adicionar ao calendário"));
        }catch(Exception e){
            android.widget.Toast.makeText(c,"Não foi possível gerar o calendário: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private static Calendar nextDate(int day,String hm){
        Calendar now=Calendar.getInstance();
        Calendar d=Calendar.getInstance();
        String[] p=hm.split(":");
        d.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));
        d.set(Calendar.MINUTE,Integer.parseInt(p[1]));
        d.set(Calendar.SECOND,0); d.set(Calendar.MILLISECOND,0);
        int delta=(day-d.get(Calendar.DAY_OF_WEEK)+7)%7;
        if(delta==0 && d.getTimeInMillis()<=now.getTimeInMillis()) delta=7;
        d.add(Calendar.DAY_OF_MONTH,delta);
        return d;
    }

    private static String fmt(Calendar c){
        return new SimpleDateFormat("yyyyMMdd'T'HHmmss",Locale.US).format(c.getTime());
    }
    private static String escape(String s){return s.replace("\\","\\\\").replace(",","\\,").replace(";","\\;").replace("\n","\\n");}
}
