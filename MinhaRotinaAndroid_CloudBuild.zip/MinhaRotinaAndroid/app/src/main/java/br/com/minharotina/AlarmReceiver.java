package br.com.minharotina;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL="routine_alerts";
    @Override public void onReceive(Context c, Intent in){
        String title=in.getStringExtra("title"); boolean sound=in.getBooleanExtra("sound",true);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            Uri u=sound? RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM):null;
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Minha Rotina",NotificationManager.IMPORTANCE_HIGH);
            if(u!=null) ch.setSound(u,null); nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(c,CHANNEL):new android.app.Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Minha Rotina").setContentText(title).setAutoCancel(true).setContentIntent(pi).setCategory(android.app.Notification.CATEGORY_ALARM).setPriority(android.app.Notification.PRIORITY_HIGH);
        nm.notify(in.getIntExtra("id",(int)System.currentTimeMillis()),b.build());
        if(c.getSharedPreferences(MainActivity.PREFS,0).getBoolean("enabled",false)) AlarmScheduler.scheduleNext(c,in.getIntExtra("day",1),in.getStringExtra("time"),title,sound,in.getIntExtra("id",1000));
    }
}
