package br.com.minharotina;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    public static final String PREFS = "routine_native";
    private WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(this), "Android");
        web.loadUrl("file:///android_asset/minha_rotina.html");
    }

    public void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 900);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                catch (Exception ignored) {}
            }
        }
        Toast.makeText(this, "Permissões de notificações/alarmes solicitadas.", Toast.LENGTH_SHORT).show();
    }

    public static class AndroidBridge {
        private final MainActivity a;
        AndroidBridge(MainActivity a) { this.a = a; }
        @JavascriptInterface public void requestNotifications() { a.runOnUiThread(a::askNotificationPermission); }
        @JavascriptInterface public void syncAlarms(int lead, boolean enabled, boolean sound) {
            if (!enabled) { AlarmScheduler.cancelAll(a); return; }
            a.runOnUiThread(a::askNotificationPermission);
            AlarmScheduler.scheduleAll(a, lead, sound);
        }
        @JavascriptInterface public void exportCalendar() { CalendarExporter.exportAndShare(a); }
    }
}
