# Minha Rotina — Android

Aplicativo de rotina semanal com interface escura/minimalista, WebView, armazenamento local, notificações e alarmes nativos.

## Gerar o APK pelo celular usando GitHub Actions

1. Crie uma conta no GitHub e um repositório novo (pode ser privado).
2. Extraia este ZIP no celular.
3. Envie **todos os arquivos e pastas que estão dentro de `MinhaRotinaAndroid`** para o repositório, preservando a pasta `.github/workflows`.
4. No GitHub, abra a aba **Actions**.
5. Selecione **Build Minha Rotina APK**.
6. Toque em **Run workflow**.
7. Aguarde o trabalho terminar com ✓.
8. Abra a execução concluída e, em **Artifacts**, baixe `MinhaRotina-debug-apk`.
9. Extraia o ZIP baixado e instale `app-debug.apk` no celular.

O workflow usa Java 17 e Gradle 8.9 e faz a compilação na infraestrutura do GitHub Actions. A ação oficial `gradle/actions/setup-gradle` permite instalar uma versão específica do Gradle diretamente no runner.
