package br.com.minharotina;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{ @Override public void onReceive(Context c,Intent i){ String tasks=c.getSharedPreferences(MainActivity.PREFS,0).getString("tasks","[]"); int lead=c.getSharedPreferences(MainActivity.PREFS,0).getInt("lead",10); boolean enabled=c.getSharedPreferences(MainActivity.PREFS,0).getBoolean("enabled",false); boolean sound=c.getSharedPreferences(MainActivity.PREFS,0).getBoolean("sound",true); if(enabled) AlarmScheduler.scheduleAll(c,tasks,lead,sound); } }
